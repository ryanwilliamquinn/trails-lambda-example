'use strict'

const bcrypt = require('bcrypt-nodejs')

module.exports = {
  handler: (event, context, callback) => {
    console.log('starting')
    const salt = bcrypt.genSaltSync(13)
    console.log('generated salt')
    const hash = bcrypt.hashSync(event.input, salt)
    console.log('done')
    callback(null, hash)
  }

}
